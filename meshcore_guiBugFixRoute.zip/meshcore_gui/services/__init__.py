"""
Business logic services — bot, cache, deduplication and route building.
"""
